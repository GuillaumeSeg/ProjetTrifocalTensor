requirement :
- SDL : sudo apt-get install libsdl1.2-dev
- SDL-image : sudo apt-get install libsdl-image1.2-dev
- eigen : http://eigen.tuxfamily.org/
	* extract the archive (at /home/[user]/ for example)
	* rename "eigen-eigen-5097c01bcdc4/" to "eigen/"

run sample :
make
./tensor


